package com.codingdojo.programastelevision;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgramastelevisionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProgramastelevisionApplication.class, args);
	}

}
