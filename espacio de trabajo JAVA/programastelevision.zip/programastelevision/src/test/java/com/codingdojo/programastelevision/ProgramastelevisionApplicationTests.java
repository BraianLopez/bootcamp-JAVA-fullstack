package com.codingdojo.programastelevision;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgramastelevisionApplicationTests {

	@Test
	void contextLoads() {
	}

}
