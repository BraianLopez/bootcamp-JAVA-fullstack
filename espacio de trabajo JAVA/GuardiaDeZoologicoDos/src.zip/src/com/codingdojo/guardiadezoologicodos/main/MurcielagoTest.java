package com.codingdojo.guardiadezoologicodos.main;

import com.codingdojo.guardiadezoologicodos.clases.Murcielago;

public class MurcielagoTest {

	public static void main(String[] args) {
		Murcielago batMan = new Murcielago();
		batMan.atacarCiudad();
		batMan.atacarCiudad();
		batMan.atacarCiudad();
		batMan.comerHumano();
		batMan.comerHumano();
		batMan.volar();
		batMan.volar();
		batMan.mostrarEnergia();
	}

}
