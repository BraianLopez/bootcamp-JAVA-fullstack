package com.codingdojo.laboratoriodecanciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaboratoriodecancionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(LaboratoriodecancionesApplication.class, args);
	}

}
